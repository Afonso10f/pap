// ALTERAR ESTES DADOS NA AULA
// =========================
// CONFIGURAÇÃO
// =========================

const SERVER_URL =
"wss://2489-2001-8a0-f270-7300-ad30-a77c-2f4d-6411.ngrok-free.app";

const CLIENT_TAG = "CLIENT6";
const API_LEVEL = "1.0";

// =========================
// VARIÁVEIS
// =========================

let socket = null;
let ROOM_CODE = "";

// =========================
// ELEMENTOS
// =========================

const connectBtn =
document.getElementById("connectBtn");

const sendBtn =
document.getElementById("sendBtn");

const usernameInput =
document.getElementById("username");

const roomInput =
document.getElementById("roomInput");

const messageInput =
document.getElementById("messageInput");

const messages =
document.getElementById("messages");

const statusDiv =
document.getElementById("status");

const typingDiv =
document.getElementById("typing");

// =========================
// FUNÇÕES
// =========================

function addMessage(text, type="received"){

    const div = document.createElement("div");

    div.classList.add("message");
    div.classList.add(type);

    div.textContent = text;

    messages.appendChild(div);

    messages.scrollTop =
    messages.scrollHeight;
}

function setOnline(){

    statusDiv.textContent = "Online";

    statusDiv.className =
    "status online";
}

function setOffline(){

    statusDiv.textContent = "Offline";

    statusDiv.className =
    "status offline";
}

// =========================
// LIGAÇÃO
// =========================
var username =""
connectBtn.onclick = () => {

    username =
    usernameInput.value.trim();

    ROOM_CODE =
    roomInput.value.trim();

    // VALIDAÇÃO NOME

    if(username === ""){

        alert("Nome vazio");

        return;
    }

    // VALIDAÇÃO SALA

    if(ROOM_CODE === ""){

        alert("Sala vazia");

        return;
    }

    // CRIAR SOCKET

    socket =
    new WebSocket(SERVER_URL);

    // =====================
    // OPEN
    // =====================

    socket.onopen = () => {

        console.log("Ligado");

        setOnline();

        addMessage(
            "Ligação estabelecida",
            "system"
        );

        // JOIN

      const joinMessage = {

    type: "join",

    name: username,

    room: ROOM_CODE,

    client_tag: 'A12',

};
console.log(joinMessage);

socket.send(
    JSON.stringify(joinMessage)
);
    };

    // =====================
    // MESSAGE
    // =====================

    socket.onmessage = (event) => {

        console.log(event.data);

        try{

            const data =
            JSON.parse(event.data);

            switch(data.type){

                // =================
                // CHAT
                // =================

               case "message":

    const sender = data.from;

    const text =
    data.message || data.text || "";

    // NÃO mostrar mensagens enviadas por mim
    // porque já aparecem no addMessage("sent")

    if(data.client === CLIENT_TAG){

        return;
    }
    if(username != data.from)
    addMessage(
        `${sender}: ${text}`,
        "received"
    );

break;

                // =================
                // SISTEMA
                // =================

                case "system":

                    addMessage(
                        data.message || data.text, 
                        "system"
                    );

                break;

                // =================
                // USERS
                // =================

                case "users":

                    console.log(
                        "Lista users:",
                        data
                    );

                break;

                // =================
                // TYPING
                // =================

                case "typing":

                    typingDiv.textContent =

                    `${data.name || "Alguém"} está a escrever...`;

                    setTimeout(() => {

                        typingDiv.textContent = "";

                    }, 1500);

                break;

                // =================
                // ERROR
                // =================

                case "error":

                    addMessage(
                        data.message || "Erro",
                        "error"
                    );

                break;

                // =================
                // DESCONHECIDO
                // =================

                default:

                    console.log(
                        "Tipo desconhecido:",
                        data.type
                    );
            }

        }catch(err){

            console.error(err);

            addMessage(
                "JSON inválido recebido",
                "error"
            );
        }
    };

    // =====================
    // ERROR
    // =====================

    socket.onerror = (error) => {

        console.error(error);

        addMessage(
            "Erro de ligação",
            "error"
        );
    };

    // =====================
    // CLOSE
    // =====================

    socket.onclose = (event) => {

        console.log(event);

        setOffline();

        addMessage(

            `Ligação fechada | Código ${event.code}`,

            "error"
        );

        sendBtn.disabled = true;
    };
};

// =========================
// ENVIAR MENSAGEM
// =========================

sendBtn.onclick = () => {

    // LIGAÇÃO FECHADA

    if(
        !socket ||
        socket.readyState !== WebSocket.OPEN
    ){

        alert("Ligação fechada");

        return;
    }

    const text =
    messageInput.value.trim();

    // MENSAGEM VAZIA

    if(text === ""){

        return;
    }

    const message = {

        type:"message",

        text:text,

        
    };

    socket.send(
        JSON.stringify(message)
    );

    addMessage(
        `Tu: ${text}`,
        "sent"
    );

    messageInput.value = "";
};

// =========================
// TYPING
// =========================

messageInput.addEventListener(
    "input",
    () => {

        if(
            socket &&
            socket.readyState === WebSocket.OPEN
        ){

            const typingMessage = {

                type:"typing",

                typing:true,

                room:ROOM_CODE,

                client:CLIENT_TAG
            };

            socket.send(
                JSON.stringify(typingMessage)
            );
        }
    }
);